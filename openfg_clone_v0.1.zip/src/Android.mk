LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := openfg_clone
LOCAL_SRC_FILES := main.cpp
LOCAL_LDLIBS := -llog -landroid -lEGL -lGLESv2
LOCAL_CFLAGS := -fvisibility=default
LOCAL_CPPFLAGS := -std=c++17
include $(BUILD_SHARED_LIBRARY)
