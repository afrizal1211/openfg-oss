APP_ABI := arm64-v8a armeabi-v7a
APP_PLATFORM := android-26
APP_STL := c++_static
