LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := openfg_clone
LOCAL_SRC_FILES := main.cpp hooks.cpp hooks_vulkan.cpp config.cpp frame_processor.cpp fsr.cpp
LOCAL_LDLIBS := -llog -landroid -lEGL -lGLESv3 -ldl -lvulkan
LOCAL_CFLAGS := -fvisibility=default -O2
LOCAL_CPPFLAGS := -std=c++17
include $(BUILD_SHARED_LIBRARY)
